package com.example.asmandroidnangcao.Model;

public class Feed {
    private String url;
    private String title ;
    private String link;
    private String author;
    private String description;
    private String image;

    public String getUrl() {
        return url;
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public String getAuthor() {
        return author;
    }

    public String getDescription() {
        return description;
    }

    public String getImage() {
        return image;
    }
}
